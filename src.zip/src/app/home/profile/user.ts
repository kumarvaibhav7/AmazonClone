export class user{
    id:number|undefined;
    name:string|undefined;
}